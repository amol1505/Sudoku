import Distribution.Simple
main = defaultMain
